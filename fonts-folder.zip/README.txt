Place your TTF font files into the 'fonts' directory.
Example: DejaVuSans.ttf or Roboto-Regular.ttf
Make sure index.js points to an existing font filename.
